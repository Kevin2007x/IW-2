function csoma(){
    let n1  = document.getElementById("n1").value
    let n2 = document.getElementById("n2").value

    const total = n1 + n2

    alert("A soma é: " + total)
}

function cnome(){
    let n = document.getElementById("nome").value
    alert("Seu nome é: " + n)
}

function ola(){
    console.log("Olá JS")
    alert("Vc viu o JS no Nav!")
}





