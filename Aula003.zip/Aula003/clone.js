function dados(){

    const ds = [
                     {id:1, login:"angelo", senha:"angelolindo",email:"angeloaraujo@gmail.com"},
                     {id:2, login:"Bryan", senha:"bryanlindo", email:"bryanoliveira@gmail.com"},
                     {id:3, login:"gustavo", senha:"gustavalindo", email:"gustavorangel@gmail.com"}
               ]
            const dd = JSON.stringify(ds) //text

               localStorage.setItem("banco", dd)

        return ds
}

function removebd(){
    localStorage.removeItem("banco")
}