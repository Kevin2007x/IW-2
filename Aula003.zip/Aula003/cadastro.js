function addUsuario(){

    let id = document.getElementById("id").volue
    let lg = document.getElementById("login").volue
    let sn = document.getElementById("senha").volue
    let mail = document.getElementById("gmail").volue

    const addUser = {id:id, login:lg, senha:sn, gmail:gmail}

    const bd = JSON.parse (localStorage.getItem("banco"))

console.log(bd)

return bd

}