
let c1 = "vermelho"
let c2 = "roxo"
let c3 = "amarelo"
let c4 = "branca"
let c5 = "verde"

//Formato JSON          
const json = [
                {co1:"Vermelho",cor2:"Rosa",cor3:"Amarelo",cor4:"Branca",cor5:"Verde"},
                {fr1:"Morango",fr12:"Laranja",fr3:"Melão",fr4:"Limãoneve",fr5:"Abacate"}
]

const dados = [c1,c2,c3,c4,c5]

let cor = "roxo"

//for(let i=0;i<10;i = i + i)
for(let i=0;i<dados.length;i++){

    if(cor == dados[i]){
        console.log("Encontrou" + i)
        break
     }else{
        console.log("Não encontrou!")
     }
     

}


//console.log(dados.length)